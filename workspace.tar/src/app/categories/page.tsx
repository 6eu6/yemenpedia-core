import { db } from '@/lib/db'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { FileText, ArrowLeft } from 'lucide-react'

export const metadata = {
  title: 'الأقسام | يمنبيديا',
  description: 'استكشف أقسام موسوعة اليمن الوطنية'
}

export default async function CategoriesPage() {
  const categories = await db.category.findMany({
    where: { isActive: true, parentId: null },
    include: {
      children: { where: { isActive: true } },
      _count: { select: { articles: { where: { status: 'APPROVED' } } } }
    },
    orderBy: { order: 'asc' }
  })

  const totalArticles = await db.article.count({
    where: { status: 'APPROVED' }
  })

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Hero */}
      <div className="bg-gradient-to-br from-gray-900 to-red-950 text-white py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold text-center mb-4">أقسام الموسوعة</h1>
          <p className="text-center text-gray-300 max-w-2xl mx-auto">
            استكشف المعرفة اليمنية من خلال أقسامنا المتنوعة
          </p>
          <div className="flex justify-center mt-6">
            <Badge variant="secondary" className="bg-white/20 text-lg py-2 px-4">
              <FileText className="ml-2 h-4 w-4" />
              {totalArticles.toLocaleString('ar-YE')} مقال
            </Badge>
          </div>
        </div>
      </div>

      {/* Categories Grid */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {categories.map((category) => (
            <Link key={category.id} href={`/category/${category.slug}`}>
              <Card className="h-full hover:shadow-xl transition-all hover:-translate-y-1 border-0 shadow-lg">
                <CardContent className="p-6 text-center">
                  <div className="text-5xl mb-4">{category.icon || '📁'}</div>
                  <h2 className="text-xl font-bold mb-2">{category.name}</h2>
                  {category.description && (
                    <p className="text-sm text-gray-500 mb-4 line-clamp-2">
                      {category.description}
                    </p>
                  )}
                  <Badge variant="secondary">
                    {category._count.articles} مقال
                  </Badge>
                  
                  {/* Subcategories */}
                  {category.children.length > 0 && (
                    <div className="mt-4 pt-4 border-t">
                      <p className="text-xs text-gray-400 mb-2">الأقسام الفرعية:</p>
                      <div className="flex flex-wrap justify-center gap-1">
                        {category.children.slice(0, 3).map((child) => (
                          <span key={child.id} className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                            {child.name}
                          </span>
                        ))}
                        {category.children.length > 3 && (
                          <span className="text-xs text-gray-400">
                            +{category.children.length - 3}
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
