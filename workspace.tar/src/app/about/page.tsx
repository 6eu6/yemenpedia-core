import { db } from '@/lib/db'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { FileText, Users, FolderTree, Eye, Heart, Award, Globe, BookOpen } from 'lucide-react'
import Link from 'next/link'

export const metadata = {
  title: 'عن الموسوعة | يمنبيديا',
  description: 'تعرف على موسوعة اليمن الوطنية - Yemenpedia'
}

export default async function AboutPage() {
  const stats = await Promise.all([
    db.article.count({ where: { status: 'APPROVED' } }),
    db.user.count(),
    db.category.count({ where: { isActive: true } }),
    db.governorate.count()
  ])

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Hero */}
      <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-red-950 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">عن يمنبيديا</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            موسوعة اليمن الوطنية - المصدر الشامل للمعرفة عن اليمن
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          <Card className="border-0 shadow-xl">
            <CardContent className="pt-6 text-center">
              <FileText className="h-10 w-10 mx-auto mb-3 text-red-600" />
              <div className="text-3xl font-bold">{stats[0].toLocaleString('ar-YE')}</div>
              <div className="text-gray-500">مقالة</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-xl">
            <CardContent className="pt-6 text-center">
              <Users className="h-10 w-10 mx-auto mb-3 text-blue-600" />
              <div className="text-3xl font-bold">{stats[1].toLocaleString('ar-YE')}</div>
              <div className="text-gray-500">كاتب ومساهم</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-xl">
            <CardContent className="pt-6 text-center">
              <FolderTree className="h-10 w-10 mx-auto mb-3 text-green-600" />
              <div className="text-3xl font-bold">{stats[2]}</div>
              <div className="text-gray-500">قسم</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-xl">
            <CardContent className="pt-6 text-center">
              <Globe className="h-10 w-10 mx-auto mb-3 text-purple-600" />
              <div className="text-3xl font-bold">{stats[3]}</div>
              <div className="text-gray-500">محافظة</div>
            </CardContent>
          </Card>
        </div>

        {/* About Content */}
        <div className="max-w-4xl mx-auto space-y-12">
          {/* Mission */}
          <Card className="border-0 shadow-xl">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <BookOpen className="h-6 w-6 text-red-600" />
                رسالتنا
              </h2>
              <p className="text-gray-600 leading-relaxed">
                يمنبيديا هي موسوعة وطنية شاملة تهدف إلى توثيق وتجميع المعرفة عن اليمن في جميع المجالات:
                التاريخ، الجغرافيا، الثقافة، التراث، الشخصيات، الأماكن، العلوم، والأدب.
                نسعى لتكون المصدر الأول والأكثر موثوقية للمعرفة عن اليمن للباحثين والدارسين والمهتمين.
              </p>
            </CardContent>
          </Card>

          {/* Values */}
          <Card className="border-0 shadow-xl">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Heart className="h-6 w-6 text-red-600" />
                قيمنا
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-red-50 dark:bg-red-950/20 rounded-xl">
                  <h3 className="font-bold text-red-600 mb-2">المصداقية</h3>
                  <p className="text-sm text-gray-600">كل مقال يمر بمراجعة صارمة من المحققين</p>
                </div>
                <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-xl">
                  <h3 className="font-bold text-blue-600 mb-2">الشمولية</h3>
                  <p className="text-sm text-gray-600">نغطي جميع جوانب الحياة اليمنية</p>
                </div>
                <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-xl">
                  <h3 className="font-bold text-green-600 mb-2">المشاركة</h3>
                  <p className="text-sm text-gray-600">مجتمع من الكتّاب والباحثين اليمنيين</p>
                </div>
                <div className="p-4 bg-purple-50 dark:bg-purple-950/20 rounded-xl">
                  <h3 className="font-bold text-purple-600 mb-2">الانفتاح</h3>
                  <p className="text-sm text-gray-600">المحتوى متاح للجميع مجاناً</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Roles */}
          <Card className="border-0 shadow-xl">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Award className="h-6 w-6 text-red-600" />
                نظام الأدوار
              </h2>
              <div className="space-y-4">
                <div className="flex items-start gap-4 p-4 border rounded-xl">
                  <Badge className="bg-red-600">الإدارة العليا</Badge>
                  <p className="text-sm text-gray-600">إدارة كاملة للموقع والإعدادات والمستخدمين</p>
                </div>
                <div className="flex items-start gap-4 p-4 border rounded-xl">
                  <Badge className="bg-orange-600">محقق المحتوى</Badge>
                  <p className="text-sm text-gray-600">مراجعة المقالات وضمان المصداقية</p>
                </div>
                <div className="flex items-start gap-4 p-4 border rounded-xl">
                  <Badge className="bg-blue-600">مشرف القسم</Badge>
                  <p className="text-sm text-gray-600">مراجعة مقالات قسم معين</p>
                </div>
                <div className="flex items-start gap-4 p-4 border rounded-xl">
                  <Badge className="bg-green-600">الكاتب</Badge>
                  <p className="text-sm text-gray-600">كتابة المقالات والمساهمة بالمحتوى</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* CTA */}
          <div className="text-center py-8">
            <h2 className="text-2xl font-bold mb-4">انضم إلينا!</h2>
            <p className="text-gray-600 mb-6">
              كن جزءاً من أكبر مشروع لتوثيق المعرفة اليمنية
            </p>
            <div className="flex justify-center gap-4">
              <Link href="/auth/register">
                <Button className="bg-red-600 hover:bg-red-700" size="lg">
                  إنشاء حساب
                </Button>
              </Link>
              <Link href="/categories">
                <Button variant="outline" size="lg">
                  استكشف الموسوعة
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
