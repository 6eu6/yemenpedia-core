'use client'

import { Suspense } from 'react'
import { SearchPageContent } from './search-content'

export default function SearchPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-white dark:bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600 mx-auto"></div>
          <p className="mt-4 text-gray-500">جارٍ التحميل...</p>
        </div>
      </div>
    }>
      <SearchPageContent />
    </Suspense>
  )
}
