import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "يمنبيديا - موسوعة اليمن الوطنية | Yemenpedia",
  description: "المصدر الشامل للمعرفة عن اليمن - موسوعة وطنية تهتم بتوثيق تاريخ اليمن وتراثه وجغرافيته وثقافته.",
  keywords: ["يمنبيديا", "Yemenpedia", "اليمن", "Yemen", "موسوعة", "encyclopedia", "تاريخ اليمن", "ثقافة يمنية", "تراث يمني"],
  authors: [{ name: "Yemenpedia Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "يمنبيديا - موسوعة اليمن الوطنية",
    description: "المصدر الشامل للمعرفة عن اليمن",
    url: "https://yemenpedia.org",
    siteName: "Yemenpedia",
    type: "website",
    locale: "ar_YE",
  },
  twitter: {
    card: "summary_large_image",
    title: "يمنبيديا - موسوعة اليمن الوطنية",
    description: "المصدر الشامل للمعرفة عن اليمن",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return children;
}
