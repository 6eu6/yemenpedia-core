import { db } from '@/lib/db'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { FolderTree, FileText, ArrowLeft } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

interface CategoryPageProps {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({ params }: CategoryPageProps) {
  const { slug } = await params
  const category = await db.category.findUnique({
    where: { slug },
    select: { name: true, description: true }
  })

  if (!category) return { title: 'قسم غير موجود' }

  return {
    title: `${category.name} | يمنبيديا`,
    description: category.description,
  }
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const { slug } = await params
  
  const category = await db.category.findUnique({
    where: { slug },
    include: {
      children: { where: { isActive: true }, orderBy: { order: 'asc' } },
      _count: { select: { articles: { where: { status: 'APPROVED' } } } }
    }
  })

  if (!category || !category.isActive) {
    notFound()
  }

  const articles = await db.article.findMany({
    where: { 
      categoryId: category.id,
      status: 'APPROVED'
    },
    include: {
      author: { select: { name: true } },
      governorate: { select: { name: true } }
    },
    orderBy: { createdAt: 'desc' },
    take: 20
  })

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Hero */}
      <div className="bg-gradient-to-br from-gray-900 to-red-950 text-white py-12">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="flex items-center gap-2 text-sm text-gray-300 mb-4">
            <Link href="/" className="hover:text-white">الرئيسية</Link>
            <span>/</span>
            <Link href="/categories" className="hover:text-white">الأقسام</Link>
          </div>

          <div className="flex items-center gap-4">
            <div className="h-16 w-16 bg-white/10 rounded-2xl flex items-center justify-center text-3xl">
              <FolderTree className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">{category.name}</h1>
              {category.description && (
                <p className="text-gray-300 mt-2">{category.description}</p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-4 mt-6">
            <Badge variant="secondary" className="bg-white/20">
              {category._count.articles} مقال
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 max-w-6xl py-8">
        {/* Subcategories */}
        {category.children.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4">الأقسام الفرعية</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {category.children.map((child) => (
                <Link key={child.id} href={`/category/${child.slug}`}>
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-4 text-center">
                      <span className="text-2xl mb-2 block">{child.icon || '📁'}</span>
                      <h3 className="font-medium">{child.name}</h3>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Articles */}
        <div>
          <h2 className="text-xl font-bold mb-4">المقالات</h2>
          {articles.length === 0 ? (
            <Card className="border-0 shadow-lg">
              <CardContent className="p-12 text-center">
                <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p className="text-gray-500">لا توجد مقالات في هذا القسم بعد</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {articles.map((article) => (
                <Link key={article.id} href={`/article/${article.slug}`}>
                  <Card className="h-full hover:shadow-lg transition-shadow border-0">
                    <CardContent className="p-6">
                      <h3 className="font-bold text-lg mb-2 line-clamp-2">{article.title}</h3>
                      {article.excerpt && (
                        <p className="text-gray-600 text-sm line-clamp-3 mb-4">{article.excerpt}</p>
                      )}
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{article.author.name}</span>
                        {article.governorate && (
                          <Badge variant="outline">{article.governorate.name}</Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>

        <div className="mt-8">
          <Link href="/categories">
            <Button variant="ghost">
              <ArrowLeft className="ml-2 h-4 w-4" />
              عرض كل الأقسام
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
