import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const createArticleSchema = z.object({
  title: z.string().min(5, 'العنوان يجب أن يكون 5 أحرف على الأقل'),
  excerpt: z.string().optional(),
  content: z.string().min(50, 'المحتوى يجب أن يكون 50 حرف على الأقل'),
  categoryId: z.string(),
  tags: z.string().optional(),
  status: z.enum(['DRAFT', 'PENDING']).default('DRAFT'),
  authorId: z.string().optional()
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const categoryId = searchParams.get('categoryId')
    const authorId = searchParams.get('authorId')
    const limit = parseInt(searchParams.get('limit') || '10')
    const page = parseInt(searchParams.get('page') || '1')
    const skip = (page - 1) * limit

    const where: any = {}
    if (status) where.status = status
    if (categoryId) where.categoryId = categoryId
    if (authorId) where.authorId = authorId

    const [articles, total] = await Promise.all([
      db.article.findMany({
        where,
        include: {
          author: { select: { id: true, name: true, image: true } },
          category: { select: { id: true, name: true, slug: true } },
          tags: { include: { tag: true } }
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip
      }),
      db.article.count({ where })
    ])

    return NextResponse.json({
      articles,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Get articles error:', error)
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = createArticleSchema.parse(body)

    // Get authorId from request body (passed from localStorage session)
    const authorId = validatedData.authorId

    if (!authorId) {
      return NextResponse.json({ error: 'يجب تسجيل الدخول لكتابة مقال' }, { status: 401 })
    }

    // Verify user exists
    const user = await db.user.findUnique({ where: { id: authorId } })
    if (!user) {
      return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 401 })
    }

    // Generate slug from title
    const slug = validatedData.title
      .toLowerCase()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .substring(0, 100)

    // Check slug uniqueness
    const existingArticle = await db.article.findUnique({ where: { slug } })
    const uniqueSlug = existingArticle ? `${slug}-${Date.now()}` : slug

    // Create article
    const article = await db.article.create({
      data: {
        title: validatedData.title,
        slug: uniqueSlug,
        excerpt: validatedData.excerpt || '',
        content: validatedData.content,
        categoryId: validatedData.categoryId,
        authorId,
        status: validatedData.status,
        primaryLang: 'ar'
      }
    })

    // Handle tags
    if (validatedData.tags) {
      const tagNames = validatedData.tags.split(',').map(t => t.trim()).filter(Boolean)
      
      for (const tagName of tagNames) {
        const tagSlug = tagName.toLowerCase().replace(/\s+/g, '-')
        
        let tag = await db.tag.findUnique({ where: { slug: tagSlug } })
        
        if (!tag) {
          tag = await db.tag.create({
            data: { name: tagName, slug: tagSlug }
          })
        }

        await db.articleTag.create({
          data: { articleId: article.id, tagId: tag.id }
        })

        await db.tag.update({
          where: { id: tag.id },
          data: { articleCount: { increment: 1 } }
        })
      }
    }

    // Update category article count
    await db.category.update({
      where: { id: validatedData.categoryId },
      data: { articleCount: { increment: 1 } }
    })

    // Award points for article submission
    await db.user.update({
      where: { id: authorId },
      data: { points: { increment: 10 } }
    })

    return NextResponse.json({
      success: true,
      message: validatedData.status === 'PENDING' 
        ? 'تم إرسال المقال للمراجعة' 
        : 'تم حفظ المقال كمسودة',
      article
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 })
    }
    console.error('Create article error:', error)
    return NextResponse.json({ error: 'حدث خطأ أثناء إنشاء المقال' }, { status: 500 })
  }
}
