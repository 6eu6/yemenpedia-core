import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Toggle follow/unfollow
export async function POST(request: NextRequest) {
  try {
    const { followerId, followingId } = await request.json()

    if (!followerId || !followingId) {
      return NextResponse.json({ error: 'بيانات ناقصة' }, { status: 400 })
    }

    if (followerId === followingId) {
      return NextResponse.json({ error: 'لا يمكنك متابعة نفسك' }, { status: 400 })
    }

    // Check if already following
    const existing = await db.follow.findUnique({
      where: {
        followerId_followingId: { followerId, followingId }
      }
    })

    if (existing) {
      // Unfollow
      await db.follow.delete({
        where: { id: existing.id }
      })

      const followersCount = await db.follow.count({
        where: { followingId }
      })

      return NextResponse.json({ isFollowing: false, followersCount })
    } else {
      // Follow
      await db.follow.create({
        data: { followerId, followingId }
      })

      const followersCount = await db.follow.count({
        where: { followingId }
      })

      return NextResponse.json({ isFollowing: true, followersCount })
    }
  } catch (error) {
    console.error('Follow error:', error)
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 })
  }
}

// Get follow data
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const currentUserId = searchParams.get('currentUserId')

    if (!userId) {
      return NextResponse.json({ error: 'معرف المستخدم مطلوب' }, { status: 400 })
    }

    const followersCount = await db.follow.count({
      where: { followingId: userId }
    })

    const followingCount = await db.follow.count({
      where: { followerId: userId }
    })

    let isFollowing = false
    if (currentUserId && currentUserId !== userId) {
      const follow = await db.follow.findUnique({
        where: {
          followerId_followingId: { followerId: currentUserId, followingId: userId }
        }
      })
      isFollowing = !!follow
    }

    return NextResponse.json({ followersCount, followingCount, isFollowing })
  } catch (error) {
    console.error('Get follow data error:', error)
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 })
  }
}
