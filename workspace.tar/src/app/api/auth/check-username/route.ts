import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const username = searchParams.get('username')
    const excludeUserId = searchParams.get('excludeUserId') // لاستبعاد المستخدم الحالي

    if (!username || username.length < 3) {
      return NextResponse.json({ available: false })
    }

    // Check if username exists (excluding current user if provided)
    const existingUser = await db.user.findFirst({
      where: {
        username: username.toLowerCase(),
        NOT: excludeUserId ? { id: excludeUserId } : undefined
      }
    })

    return NextResponse.json({
      available: !existingUser
    })
  } catch (error) {
    console.error('Check username error:', error)
    return NextResponse.json({ available: true }) // افترض متاح في حالة الخطأ
  }
}
