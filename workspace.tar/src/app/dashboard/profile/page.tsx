'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

// Redirect /dashboard/profile to /u/username
export default function ProfileRedirect() {
  const router = useRouter()

  useEffect(() => {
    const session = localStorage.getItem('session')
    if (session) {
      try {
        const user = JSON.parse(session)
        if (user.username) {
          router.replace(`/u/${user.username}`)
        } else {
          router.replace('/dashboard')
        }
      } catch {
        router.replace('/dashboard')
      }
    } else {
      router.replace('/auth/login')
    }
  }, [router])

  return null
}
