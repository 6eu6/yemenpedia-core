'use client'

import { useTheme } from 'next-themes'
import { useState, useEffect } from 'react'
import { useLocale } from 'next-intl'
// Force rebuild
import { Header } from '@/components/layout/Header'
import { Footer } from '@/components/layout/Footer'
import { HeroSection } from '@/components/home/HeroSection'
import { CategoriesGrid } from '@/components/home/CategoriesGrid'
import { MapSection } from '@/components/home/MapSection'
import { LatestArticles } from '@/components/home/LatestArticles'
import { StatsSection } from '@/components/home/StatsSection'
import { CTASection } from '@/components/home/CTASection'
import { useRouter, usePathname } from '@/i18n/routing'

interface UserData {
  id: string
  name: string
  username: string
  role: string
  image?: string
}

// Helper function to get initial user from localStorage
function getInitialUser(): UserData | null {
  if (typeof window === 'undefined') return null
  try {
    const session = localStorage.getItem('session')
    return session ? JSON.parse(session) : null
  } catch {
    return null
  }
}

export default function Home() {
  const { theme, setTheme } = useTheme()
  const locale = useLocale()
  const router = useRouter()
  const pathname = usePathname()
  const [user, setUser] = useState<UserData | null>(getInitialUser)

  // Sync user state with localStorage changes (e.g., login in another tab)
  useEffect(() => {
    const handleStorageChange = () => {
      const session = localStorage.getItem('session')
      if (session) {
        try {
          setUser(JSON.parse(session))
        } catch {
          setUser(null)
        }
      } else {
        setUser(null)
      }
    }

    window.addEventListener('storage', handleStorageChange)
    return () => window.removeEventListener('storage', handleStorageChange)
  }, [])

  const handleThemeToggle = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark')
  }

  const handleLanguageChange = (newLang: string) => {
    // Navigate to the same page but with new locale
    router.replace(pathname, { locale: newLang })
  }

  const handleLogout = () => {
    localStorage.removeItem('session')
    setUser(null)
    window.location.href = '/'
  }

  // Only Arabic is RTL
  const isRTL = locale === 'ar'
  const dir = isRTL ? 'rtl' : 'ltr'

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-gray-900 transition-colors" dir={dir}>
      <Header
        isDark={theme === 'dark'}
        onThemeToggle={handleThemeToggle}
        currentLang={locale}
        onLanguageChange={handleLanguageChange}
        isAuthenticated={!!user}
        user={user ? { id: user.id, name: user.name, username: user.username, image: user.image, role: user.role } : undefined}
        onLogout={handleLogout}
      />
      
      <main className="flex-1">
        <HeroSection />
        <CategoriesGrid />
        <MapSection />
        <LatestArticles />
        <StatsSection />
        <CTASection />
      </main>
      
      <Footer />
    </div>
  )
}
