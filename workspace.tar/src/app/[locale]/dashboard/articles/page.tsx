'use client'

import { useState, useEffect } from 'react'
import { useRouter } from '@/i18n/routing'
import { Link } from '@/i18n/routing'
import { useTranslations, useLocale } from 'next-intl'
import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { FileText, Eye, Heart, Clock, Loader2, PenTool, Plus } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { ar, enUS } from 'date-fns/locale'

interface Article {
  id: string
  title: string
  status: string
  viewCount: number
  likeCount: number
  createdAt: string
  category?: { name: string }
}

export default function MyArticlesPage() {
  const router = useRouter()
  const t = useTranslations('dashboard')
  const tArticles = useTranslations('articles')
  const locale = useLocale()
  const [articles, setArticles] = useState<Article[]>([])
  const [isLoading, setIsLoading] = useState(true)

  const isRTL = locale === 'ar'
  const dateLocale = locale === 'ar' ? ar : enUS

  useEffect(() => {
    const session = localStorage.getItem('session')
    if (!session) {
      router.push('/auth/login')
      return
    }

    try {
      const userData = JSON.parse(session)
      fetchArticles(userData.id)
    } catch {
      router.push('/auth/login')
    }
  }, [router])

  const fetchArticles = async (userId: string) => {
    try {
      const res = await fetch(`/api/user/stats?userId=${userId}`)
      if (res.ok) {
        const data = await res.json()
        setArticles(data.articles || [])
      }
    } catch (error) {
      console.error('Error fetching articles:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return isRTL ? 'منشور' : 'Published'
      case 'PENDING':
        return isRTL ? 'قيد المراجعة' : 'Pending Review'
      case 'REJECTED':
        return isRTL ? 'مرفوض' : 'Rejected'
      default:
        return isRTL ? 'مسودة' : 'Draft'
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-red-600" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">{t('myArticles')}</h1>
          <p className="text-gray-500 mt-1">
            {isRTL ? 'قائمة بجميع مقالاتك' : 'List of all your articles'}
          </p>
        </div>
        <Link href="/dashboard/write">
          <Button className="bg-red-600 hover:bg-red-700">
            <Plus className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4`} />
            {t('writeArticle')}
          </Button>
        </Link>
      </div>

      <Card className="border-0 shadow-lg">
        <CardContent className="pt-6">
          {articles.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <FileText className="h-16 w-16 mx-auto mb-4 text-gray-300" />
              <p className="text-lg">{tArticles('noArticles')}</p>
              <Link href="/dashboard/write">
                <Button className="mt-4 bg-red-600 hover:bg-red-700">
                  <PenTool className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4`} />
                  {t('writeArticle')}
                </Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {articles.map((article) => (
                <motion.div
                  key={article.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  <div className="flex-1">
                    <h3 className="font-medium text-lg">{article.title}</h3>
                    <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                      {article.category && (
                        <span className="bg-red-100 text-red-600 px-2 py-0.5 rounded-full text-xs">
                          {article.category.name}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {article.viewCount}
                      </span>
                      <span className="flex items-center gap-1">
                        <Heart className="h-3 w-3" />
                        {article.likeCount}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {formatDistanceToNow(new Date(article.createdAt), { addSuffix: true, locale: dateLocale })}
                      </span>
                    </div>
                  </div>
                  <Badge
                    variant={
                      article.status === 'APPROVED' ? 'default' :
                      article.status === 'PENDING' ? 'secondary' :
                      article.status === 'REJECTED' ? 'destructive' : 'outline'
                    }
                  >
                    {getStatusText(article.status)}
                  </Badge>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
