'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter } from '@/i18n/routing'
import { useTranslations, useLocale } from 'next-intl'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { 
  Save, Send, Loader2, ImageIcon, Lightbulb, FileText, Clock
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { TipTapEditor } from '@/components/editor'
import type { TipTapContent } from '@/components/editor/types'

export default function WriteArticlePage() {
  const router = useRouter()
  const { toast } = useToast()
  const t = useTranslations('articleEditor')
  const tCommon = useTranslations('common')
  const locale = useLocale()
  
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [categories, setCategories] = useState<{ id: string; name: string }[]>([])
  const [editorContent, setEditorContent] = useState<TipTapContent | null>(null)
  const [editorHtml, setEditorHtml] = useState('')
  const [lastSaved, setLastSaved] = useState<Date | null>(null)
  
  const [formData, setFormData] = useState({
    title: '',
    categoryId: '',
    summary: '',
    tags: ''
  })

  const isRTL = locale === 'ar'

  // Check authentication and fetch categories
  useEffect(() => {
    const session = localStorage.getItem('session')
    if (!session) {
      router.push('/auth/login')
      return
    }

    fetch('/api/v1/categories')
      .then(res => res.json())
      .then(data => {
        if (data.categories) {
          setCategories(data.categories)
        }
      })
      .catch(console.error)
  }, [router])

  // Handle editor content changes
  const handleContentChange = useCallback((content: TipTapContent, html: string) => {
    setEditorContent(content)
    setEditorHtml(html)
  }, [])

  // Handle auto-save
  const handleAutoSave = useCallback(async (content: TipTapContent, html: string) => {
    // Auto-save draft to localStorage
    const draft = {
      title: formData.title,
      categoryId: formData.categoryId,
      summary: formData.summary,
      tags: formData.tags,
      content: content,
      html: html,
      savedAt: new Date().toISOString()
    }
    localStorage.setItem('article-draft', JSON.stringify(draft))
    setLastSaved(new Date())
  }, [formData])

  // Load saved draft
  useEffect(() => {
    const savedDraft = localStorage.getItem('article-draft')
    if (savedDraft) {
      try {
        const draft = JSON.parse(savedDraft)
        setFormData({
          title: draft.title || '',
          categoryId: draft.categoryId || '',
          summary: draft.summary || '',
          tags: draft.tags || ''
        })
        // Set editor content from draft
        if (draft.content) {
          setEditorContent(draft.content)
        }
      } catch (e) {
        console.error('Failed to load draft:', e)
      }
    }
  }, [])

  // Calculate word count from editor
  const wordCount = editorHtml.replace(/<[^>]*>/g, '').split(/\s+/).filter(Boolean).length
  const readTime = Math.max(1, Math.ceil(wordCount / 200))

  // Manual save draft
  const handleSaveDraft = async () => {
    setIsSaving(true)
    await new Promise(resolve => setTimeout(resolve, 500))
    
    const draft = {
      title: formData.title,
      categoryId: formData.categoryId,
      summary: formData.summary,
      tags: formData.tags,
      content: editorContent,
      html: editorHtml,
      savedAt: new Date().toISOString()
    }
    localStorage.setItem('article-draft', JSON.stringify(draft))
    setLastSaved(new Date())
    
    setIsSaving(false)
    toast.toast({ title: t('draftSaved') })
  }

  // Submit article
  const handleSubmit = async () => {
    if (!formData.title || !formData.categoryId || !editorContent) {
      toast.toast({ variant: 'destructive', title: tCommon('error'), description: tCommon('required') })
      return
    }

    setIsLoading(true)
    try {
      const session = localStorage.getItem('session')
      const user = session ? JSON.parse(session) : null

      // Generate slug from title
      const slug = formData.title
        .toLowerCase()
        .replace(/[^\w\s-]/g, '')
        .replace(/\s+/g, '-')
        .substring(0, 100)

      const res = await fetch('/api/articles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formData.title,
          slug: slug,
          content: editorContent,
          excerpt: formData.summary,
          categoryId: formData.categoryId,
          tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean),
          authorId: user?.id,
          status: 'PENDING'
        })
      })

      if (res.ok) {
        // Clear draft
        localStorage.removeItem('article-draft')
        toast.toast({ title: t('published') })
        router.push('/dashboard/articles')
      } else {
        const data = await res.json()
        toast.toast({ variant: 'destructive', title: tCommon('error'), description: data.error })
      }
    } catch {
      toast.toast({ variant: 'destructive', title: tCommon('error') })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">{t('title')}</h1>
          <p className="text-gray-500 mt-1">
            {isRTL ? 'اكتب مقالاً جديداً للموسوعة' : 'Write a new article for the encyclopedia'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {lastSaved && (
            <span className="text-sm text-gray-500">
              {isRTL ? `آخر حفظ: ${lastSaved.toLocaleTimeString('ar')}` : `Last saved: ${lastSaved.toLocaleTimeString()}`}
            </span>
          )}
          <Button variant="outline" onClick={handleSaveDraft} disabled={isSaving}>
            {isSaving ? (
              <Loader2 className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4 animate-spin`} />
            ) : (
              <Save className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4`} />
            )}
            {t('saveDraft')}
          </Button>
          <Button className="bg-red-600 hover:bg-red-700" onClick={handleSubmit} disabled={isLoading}>
            {isLoading ? (
              <Loader2 className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4 animate-spin`} />
            ) : (
              <Send className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4`} />
            )}
            {t('submitForReview')}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Editor Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Title */}
          <Card className="border-0 shadow-lg">
            <CardContent className="pt-6">
              <Label htmlFor="title" className="text-lg font-medium">{t('articleTitle')}</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder={t('articleTitlePlaceholder')}
                className="mt-2 text-lg"
              />
            </CardContent>
          </Card>

          {/* Category */}
          <Card className="border-0 shadow-lg">
            <CardContent className="pt-6">
              <Label className="text-lg font-medium">{t('category')}</Label>
              <Select value={formData.categoryId} onValueChange={(value) => setFormData({ ...formData, categoryId: value })}>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder={t('selectCategory')} />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* TipTap Editor */}
          <Card className="border-0 shadow-lg">
            <CardContent className="pt-6">
              <TipTapEditor
                content={editorContent}
                placeholder={isRTL ? 'ابدأ الكتابة هنا...' : 'Start writing here...'}
                onContentChange={handleContentChange}
                onAutoSave={handleAutoSave}
                articleSlug={formData.title.toLowerCase().replace(/\s+/g, '-').substring(0, 50) || 'article'}
              />
              <div className="flex items-center gap-4 mt-4 text-sm text-gray-500">
                <span className="flex items-center gap-1">
                  <FileText className="h-4 w-4" />
                  {t('wordCount')}: {wordCount}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {t('readTime')}: ~{readTime} {t('minutes')}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Summary */}
          <Card className="border-0 shadow-lg">
            <CardContent className="pt-6">
              <Label>{t('summary')}</Label>
              <Textarea
                value={formData.summary}
                onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                placeholder={t('summaryPlaceholder')}
                className="mt-2"
                rows={3}
              />
            </CardContent>
          </Card>

          {/* Tags */}
          <Card className="border-0 shadow-lg">
            <CardContent className="pt-6">
              <Label>{t('tags')}</Label>
              <Input
                value={formData.tags}
                onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                placeholder={t('tagsPlaceholder')}
                className="mt-2"
              />
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Featured Image */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <ImageIcon className="h-5 w-5" />
                {t('featuredImage')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button variant="outline" className="w-full">
                <ImageIcon className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4`} />
                {t('uploadImage')}
              </Button>
            </CardContent>
          </Card>

          {/* Writing Tips */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Lightbulb className="h-5 w-5 text-yellow-500" />
                {t('writingTips')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2" />
                  {t('tip1')}
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2" />
                  {t('tip2')}
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2" />
                  {t('tip3')}
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2" />
                  {t('tip4')}
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
