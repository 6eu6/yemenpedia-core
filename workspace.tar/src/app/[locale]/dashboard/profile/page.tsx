'use client'

import { useState, useEffect } from 'react'
import { useRouter } from '@/i18n/routing'
import { Link } from '@/i18n/routing'
import { useTranslations, useLocale } from 'next-intl'
import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { 
  User, Mail, MapPin, Calendar, Link as LinkIcon, 
  Loader2, Camera, Save
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface UserData {
  id: string
  name: string
  username: string
  email: string
  role: string
  image?: string
  bio?: string
  location?: string
  website?: string
  createdAt: string
}

export default function ProfilePage() {
  const router = useRouter()
  const { toast } = useToast()
  const t = useTranslations('profile')
  const tCommon = useTranslations('common')
  const locale = useLocale()
  const [user, setUser] = useState<UserData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    bio: '',
    location: '',
    website: ''
  })

  const isRTL = locale === 'ar'

  useEffect(() => {
    const session = localStorage.getItem('session')
    if (!session) {
      router.push('/auth/login')
      return
    }

    try {
      const userData = JSON.parse(session)
      setUser(userData)
      setFormData({
        name: userData.name || '',
        bio: userData.bio || '',
        location: userData.location || '',
        website: userData.website || ''
      })
    } catch {
      router.push('/auth/login')
    } finally {
      setIsLoading(false)
    }
  }, [router])

  const handleSave = async () => {
    setIsSaving(true)
    try {
      const res = await fetch('/api/user/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user?.id,
          ...formData
        })
      })

      if (res.ok) {
        const updatedUser = { ...user, ...formData }
        localStorage.setItem('session', JSON.stringify(updatedUser))
        setUser(updatedUser)
        toast.toast({ title: tCommon('success'), description: tCommon('success') })
      } else {
        toast.toast({ variant: 'destructive', title: tCommon('error') })
      }
    } catch {
      toast.toast({ variant: 'destructive', title: tCommon('error') })
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-red-600" />
      </div>
    )
  }

  if (!user) return null

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{t('editProfile')}</h1>
        <p className="text-gray-500 mt-1">
          {isRTL ? 'تعديل معلومات ملفك الشخصي' : 'Edit your profile information'}
        </p>
      </div>

      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            {isRTL ? 'المعلومات الأساسية' : 'Basic Information'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Avatar */}
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center">
              <span className="text-3xl font-bold text-red-600">
                {user.name?.charAt(0) || (isRTL ? 'ي' : 'Y')}
              </span>
            </div>
            <Button variant="outline">
              <Camera className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4`} />
              {t('editAvatar')}
            </Button>
          </div>

          {/* Name */}
          <div className="space-y-2">
            <Label htmlFor="name">{isRTL ? 'الاسم' : 'Name'}</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder={isRTL ? 'أدخل اسمك' : 'Enter your name'}
            />
          </div>

          {/* Bio */}
          <div className="space-y-2">
            <Label htmlFor="bio">{t('bio')}</Label>
            <Textarea
              id="bio"
              value={formData.bio}
              onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
              placeholder={t('noBio')}
              rows={3}
            />
          </div>

          {/* Location */}
          <div className="space-y-2">
            <Label htmlFor="location" className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              {t('location')}
            </Label>
            <Input
              id="location"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              placeholder={isRTL ? 'مثال: صنعاء، اليمن' : 'Example: Sana\'a, Yemen'}
            />
          </div>

          {/* Website */}
          <div className="space-y-2">
            <Label htmlFor="website" className="flex items-center gap-2">
              <LinkIcon className="h-4 w-4" />
              {t('website')}
            </Label>
            <Input
              id="website"
              type="url"
              value={formData.website}
              onChange={(e) => setFormData({ ...formData, website: e.target.value })}
              placeholder="https://example.com"
            />
          </div>

          <div className="flex justify-end">
            <Button onClick={handleSave} disabled={isSaving} className="bg-red-600 hover:bg-red-700">
              {isSaving ? (
                <Loader2 className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4 animate-spin`} />
              ) : (
                <Save className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4`} />
              )}
              {tCommon('save')}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Account Info */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle>{isRTL ? 'معلومات الحساب' : 'Account Information'}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            <Mail className="h-4 w-4 text-gray-400" />
            <div>
              <p className="text-sm text-gray-500">{isRTL ? 'البريد الإلكتروني' : 'Email'}</p>
              <p>{user.email}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Calendar className="h-4 w-4 text-gray-400" />
            <div>
              <p className="text-sm text-gray-500">{t('joined')}</p>
              <p>{new Date(user.createdAt).toLocaleDateString(locale === 'ar' ? 'ar-YE' : 'en-US')}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline">{user.role}</Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
