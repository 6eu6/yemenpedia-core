'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { YemenMap, governorates } from '@/components/map/yemen-map'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { MapPin, Search, Grid, List } from 'lucide-react'

export default function MapPage() {
  const router = useRouter()
  const [selectedGov, setSelectedGov] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [viewMode, setViewMode] = useState<'map' | 'grid'>('map')

  const filteredGovernorates = governorates.filter(gov =>
    gov.name.includes(searchQuery) || 
    gov.nameEn?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    gov.capital?.includes(searchQuery)
  )

  const handleGovernorateClick = (governorate: typeof governorates[0]) => {
    const slug = governorate.name.replace(/\s+/g, '-')
    router.push(`/governorate/${slug}`)
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Hero */}
      <div className="bg-gradient-to-br from-red-900 to-red-950 text-white py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold text-center mb-4">خريطة اليمن التفاعلية</h1>
          <p className="text-center text-gray-300 max-w-2xl mx-auto">
            اضغط على أي محافظة لاستكشاف مقالاتها ومعالمها
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Controls */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="ابحث عن محافظة..."
              className="pr-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Button
              variant={viewMode === 'map' ? 'default' : 'outline'}
              onClick={() => setViewMode('map')}
              className={viewMode === 'map' ? 'bg-red-600 hover:bg-red-700' : ''}
            >
              <MapPin className="ml-2 h-4 w-4" />
              الخريطة
            </Button>
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              onClick={() => setViewMode('grid')}
              className={viewMode === 'grid' ? 'bg-red-600 hover:bg-red-700' : ''}
            >
              <Grid className="ml-2 h-4 w-4" />
              الشبكة
            </Button>
          </div>
        </div>

        {/* Map View */}
        {viewMode === 'map' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6"
          >
            <YemenMap
              onGovernorateClick={handleGovernorateClick}
              selectedGovernorate={selectedGov}
              className="h-[600px]"
            />
          </motion.div>
        )}

        {/* Grid View */}
        {viewMode === 'grid' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4"
          >
            {filteredGovernorates.map((gov) => (
              <Card
                key={gov.id}
                className="cursor-pointer hover:shadow-lg transition-shadow border-0"
                onClick={() => handleGovernorateClick(gov)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-bold">{gov.name}</h3>
                      {gov.nameEn && (
                        <p className="text-sm text-gray-500">{gov.nameEn}</p>
                      )}
                    </div>
                    <span className="text-2xl">
                      {gov.region === 'north' ? '🏔️' : 
                       gov.region === 'west' ? '🌊' :
                       gov.region === 'east' ? '🏜️' :
                       gov.region === 'south' ? '🌴' :
                       gov.region === 'island' ? '🏝️' : '🏛️'}
                    </span>
                  </div>
                  <div className="mt-3 space-y-1 text-sm text-gray-600">
                    {gov.capital && (
                      <div className="flex justify-between">
                        <span>العاصمة:</span>
                        <span className="font-medium">{gov.capital}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>السكان:</span>
                      <span className="font-medium">{gov.population.toLocaleString('ar-YE')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>المقالات:</span>
                      <Badge variant="secondary">{gov.articleCount}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </motion.div>
        )}

        {/* Stats */}
        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="border-0 shadow-lg">
            <CardContent className="pt-6 text-center">
              <div className="text-3xl font-bold text-red-600">{governorates.length}</div>
              <div className="text-sm text-gray-500">محافظة</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="pt-6 text-center">
              <div className="text-3xl font-bold text-red-600">
                {governorates.reduce((sum, g) => sum + g.population, 0).toLocaleString('ar-YE')}
              </div>
              <div className="text-sm text-gray-500">نسمة</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="pt-6 text-center">
              <div className="text-3xl font-bold text-red-600">
                {governorates.reduce((sum, g) => sum + g.articleCount, 0)}
              </div>
              <div className="text-sm text-gray-500">مقال</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="pt-6 text-center">
              <div className="text-3xl font-bold text-red-600">527,970</div>
              <div className="text-sm text-gray-500">كم² مساحة</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
