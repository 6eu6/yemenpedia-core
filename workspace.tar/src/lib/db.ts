import { PrismaClient } from '@prisma/client'

// GOVERNANCE: Article IV, Section 4.1 - Zero Hardcoding Policy
// Use SUPABASE_POOLER_URL to bypass sandbox SQLite conflict
const databaseUrl = process.env.SUPABASE_POOLER_URL || process.env.DATABASE_URL

if (!databaseUrl) {
  throw new Error('DATABASE_URL or SUPABASE_POOLER_URL must be set in environment variables')
}

// Force fresh Prisma Client instance
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Create Prisma client with explicit datasourceUrl to bypass sandbox conflict
const createPrismaClient = () => {
  return new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
    datasourceUrl: databaseUrl
  })
}

// Always create new client in development to avoid stale cache
export const db =
  process.env.NODE_ENV === 'development'
    ? createPrismaClient()
    : (globalForPrisma.prisma ?? createPrismaClient())

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db

// Re-export types
export * from '@prisma/client'
