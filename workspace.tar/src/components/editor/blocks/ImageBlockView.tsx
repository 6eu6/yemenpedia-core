/**
 * Image Block View Component
 * 
 * Interactive image block with:
 * - Media picker integration
 * - Mandatory alt text editing
 * - Caption editing
 * - Alignment controls
 * - Lazy loading
 */

'use client'

import { useState, useCallback, useRef, useEffect } from 'react'
import { NodeViewWrapper, NodeViewContent } from '@tiptap/react'
import { Image as ImageIcon, AlignLeft, AlignCenter, AlignRight, Trash2, Edit2, X, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import type { ImageBlockProps, ImageNodeAttributes } from '../types'

export function ImageBlockView({ 
  node, 
  selected, 
  editor, 
  updateAttributes, 
  deleteNode 
}: ImageBlockProps) {
  const [showDialog, setShowDialog] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [editAlt, setEditAlt] = useState(node.attrs.alt || '')
  const [editCaption, setEditCaption] = useState(node.attrs.caption || '')
  const [editTitle, setEditTitle] = useState(node.attrs.title || '')
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  const { src, alt, caption, title, width, height, alignment } = node.attrs
  
  const hasImage = src && src.length > 0
  
  // Check if alt text is missing (accessibility warning)
  const hasAltWarning = hasImage && (!alt || alt.trim() === '')
  
  useEffect(() => {
    setEditAlt(alt || '')
    setEditCaption(caption || '')
    setEditTitle(title || '')
  }, [alt, caption, title])
  
  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    
    setIsUploading(true)
    
    try {
      const formData = new FormData()
      formData.append('file', file)
      formData.append('type', 'image')
      formData.append('slug', editor.storage.articleSlug || 'article')
      formData.append('altText', editAlt)
      
      const response = await fetch('/api/media/upload', {
        method: 'POST',
        body: formData,
      })
      
      const result = await response.json()
      
      if (result.success) {
        updateAttributes({
          src: result.data.url,
          width: result.data.width,
          height: result.data.height,
        })
      } else {
        console.error('Upload failed:', result.error)
      }
    } catch (error) {
      console.error('Upload error:', error)
    } finally {
      setIsUploading(false)
    }
  }, [editor, editAlt, updateAttributes])
  
  const handleSaveEdit = useCallback(() => {
    updateAttributes({
      alt: editAlt,
      caption: editCaption,
      title: editTitle,
    })
    setShowDialog(false)
  }, [editAlt, editCaption, editTitle, updateAttributes])
  
  const handleAlignment = useCallback((align: 'left' | 'center' | 'right') => {
    updateAttributes({ alignment: align })
  }, [updateAttributes])
  
  const alignmentClass = alignment === 'left' ? 'ml-0 mr-auto' : alignment === 'right' ? 'ml-auto mr-0' : 'mx-auto'
  
  return (
    <NodeViewWrapper className={`image-block-wrapper relative ${selected ? 'ring-2 ring-primary ring-offset-2' : ''}`}>
      {!hasImage ? (
        // Upload placeholder
        <div 
          className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-primary hover:bg-gray-50 transition-colors"
          onClick={() => fileInputRef.current?.click()}
        >
          <ImageIcon className="w-12 h-12 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-600 font-medium">اضغط لإضافة صورة</p>
          <p className="text-gray-400 text-sm mt-1">يدعم: JPG, PNG, WebP</p>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={handleFileSelect}
          />
        </div>
      ) : (
        // Image display
        <figure className={`image-block ${alignmentClass}`} style={{ maxWidth: width || '100%' }}>
          {/* Toolbar */}
          {selected && (
            <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-white border rounded-lg shadow-lg p-1 flex gap-1 z-10">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                title="تغيير الصورة"
              >
                <ImageIcon className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowDialog(true)}
                title="تعديل"
              >
                <Edit2 className="w-4 h-4" />
              </Button>
              <div className="w-px bg-gray-200 mx-1" />
              <Button
                variant={alignment === 'left' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => handleAlignment('left')}
                title="محاذاة لليسار"
              >
                <AlignLeft className="w-4 h-4" />
              </Button>
              <Button
                variant={alignment === 'center' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => handleAlignment('center')}
                title="توسيط"
              >
                <AlignCenter className="w-4 h-4" />
              </Button>
              <Button
                variant={alignment === 'right' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => handleAlignment('right')}
                title="محاذاة لليمين"
              >
                <AlignRight className="w-4 h-4" />
              </Button>
              <div className="w-px bg-gray-200 mx-1" />
              <Button
                variant="ghost"
                size="sm"
                onClick={deleteNode}
                className="text-destructive hover:text-destructive"
                title="حذف"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={handleFileSelect}
              />
            </div>
          )}
          
          {/* Image */}
          <img
            src={src}
            alt={alt || ''}
            title={title || ''}
            width={width}
            height={height}
            loading="lazy"
            decoding="async"
            className="rounded-lg max-w-full h-auto"
          />
          
          {/* Alt text warning */}
          {hasAltWarning && selected && (
            <div className="absolute top-2 right-2 bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs">
              ⚠️ النص البديل مطلوب للوصول
            </div>
          )}
          
          {/* Caption */}
          {caption && (
            <figcaption className="text-center text-gray-600 text-sm mt-2 italic">
              {caption}
            </figcaption>
          )}
        </figure>
      )}
      
      {/* Loading overlay */}
      {isUploading && (
        <div className="absolute inset-0 bg-white/80 flex items-center justify-center rounded-lg">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      )}
      
      {/* Edit Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>تعديل الصورة</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Alt text - MANDATORY */}
            <div className="space-y-2">
              <Label htmlFor="alt" className="flex items-center gap-1">
                النص البديل <span className="text-destructive">*</span>
                <span className="text-xs text-gray-400">(مطلوب للوصول)</span>
              </Label>
              <Input
                id="alt"
                value={editAlt}
                onChange={(e) => setEditAlt(e.target.value)}
                placeholder="وصف مختصر للصورة..."
                required
              />
            </div>
            
            {/* Title */}
            <div className="space-y-2">
              <Label htmlFor="title">العنوان (اختياري)</Label>
              <Input
                id="title"
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                placeholder="عنوان الصورة..."
              />
            </div>
            
            {/* Caption */}
            <div className="space-y-2">
              <Label htmlFor="caption">التعليق</Label>
              <Textarea
                id="caption"
                value={editCaption}
                onChange={(e) => setEditCaption(e.target.value)}
                placeholder="تعليق يظهر أسفل الصورة..."
                rows={2}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              <X className="w-4 h-4 ml-2" />
              إلغاء
            </Button>
            <Button onClick={handleSaveEdit} disabled={!editAlt.trim()}>
              <Check className="w-4 h-4 ml-2" />
              حفظ
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </NodeViewWrapper>
  )
}

export default ImageBlockView
