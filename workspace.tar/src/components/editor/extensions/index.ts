/**
 * TipTap Editor Extensions Index
 * 
 * Exports all custom extensions for the encyclopedia editor
 */

// Core extensions
export { ImageBlock } from './ImageBlock'
export { VideoBlock } from './VideoBlock'
export { MapBlock } from './MapBlock'
export { CitationBlock } from './CitationBlock'

// Block views
export { ImageBlockView } from './blocks/ImageBlockView'
export { VideoBlockView } from './blocks/VideoBlockView'
export { MapBlockView } from './blocks/MapBlockView'
export { CitationBlockView } from './blocks/CitationBlockView'
