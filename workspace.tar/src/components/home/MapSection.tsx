'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { MapPin, ArrowLeft, BookOpen, Users, FileText, ExternalLink } from 'lucide-react'
import { YemenMap, governorates } from '@/components/map/yemen-map'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

export function MapSection() {
  const [selectedGovernorate, setSelectedGovernorate] = useState<typeof governorates[0] | null>(null)

  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50 dark:from-gray-800 dark:to-gray-900 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5 dark:opacity-10">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23CE1126' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-red-100 dark:bg-red-900/30 rounded-full text-red-600 dark:text-red-400 text-sm mb-4"
          >
            <MapPin className="h-4 w-4" />
            استكشف اليمن
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4"
          >
            خريطة اليمن التفاعلية
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto text-lg"
          >
            اضغط على أي محافظة لاستكشاف مقالاتها ومعرفة المزيد عن تاريخها وتراثها
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Map */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-2"
          >
            <Card className="overflow-hidden border-0 shadow-2xl bg-white dark:bg-gray-800">
              <CardContent className="p-0">
                <YemenMap
                  onGovernorateClick={(gov) => setSelectedGovernorate(gov)}
                  selectedGovernorate={selectedGovernorate?.id}
                  className="w-full h-[500px] md:h-[600px]"
                />
              </CardContent>
            </Card>
          </motion.div>

          {/* Governorate Info Panel */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <Card className="h-full border-0 shadow-xl bg-white dark:bg-gray-800 overflow-hidden">
              {selectedGovernorate ? (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="h-full flex flex-col"
                >
                  {/* Header */}
                  <div className="bg-gradient-to-l from-red-600 to-red-700 p-6 text-white">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-2xl font-bold">{selectedGovernorate.name}</h3>
                        <p className="text-red-200">{selectedGovernorate.nameEn}</p>
                      </div>
                      <span className="text-4xl">
                        {selectedGovernorate.region === 'north' ? '🏔️' : 
                         selectedGovernorate.region === 'west' ? '🌊' :
                         selectedGovernorate.region === 'east' ? '🏜️' :
                         selectedGovernorate.region === 'south' ? '🌴' :
                         selectedGovernorate.region === 'island' ? '🏝️' : '🏛️'}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 p-6">
                    <div className="space-y-4">
                      <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-900/50 flex items-center justify-center">
                          <MapPin className="h-5 w-5 text-red-600" />
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 dark:text-gray-400">العاصمة</p>
                          <p className="font-medium text-gray-900 dark:text-white">{selectedGovernorate.capital}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center">
                          <Users className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 dark:text-gray-400">عدد السكان</p>
                          <p className="font-medium text-gray-900 dark:text-white">{selectedGovernorate.population.toLocaleString()}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/50 flex items-center justify-center">
                          <FileText className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 dark:text-gray-400">المقالات المنشورة</p>
                          <p className="font-medium text-gray-900 dark:text-white">{selectedGovernorate.articleCount} مقالة</p>
                        </div>
                      </div>
                    </div>

                    <div className="mt-6 space-y-3">
                      <Link href={`/governorate/${selectedGovernorate.id}`}>
                        <Button className="w-full bg-red-600 hover:bg-red-700 text-white shadow-lg shadow-red-600/25">
                          <BookOpen className="h-4 w-4 ml-2" />
                          استكشف المقالات
                          <ArrowLeft className="mr-2 h-4 w-4" />
                        </Button>
                      </Link>
                      <Link href={`/governorate/${selectedGovernorate.id}/map`}>
                        <Button variant="outline" className="w-full border-gray-200 dark:border-gray-700">
                          <ExternalLink className="h-4 w-4 ml-2" />
                          عرض على الخريطة
                        </Button>
                      </Link>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center p-8">
                  <motion.div
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    <div className="w-24 h-24 rounded-full bg-gradient-to-br from-red-100 to-red-200 dark:from-red-900/30 dark:to-red-800/30 flex items-center justify-center mb-6">
                      <MapPin className="h-12 w-12 text-red-600" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                      اختر محافظة
                    </h3>
                    <p className="text-gray-500 dark:text-gray-400 max-w-xs">
                      اضغط على أي محافظة في الخريطة لعرض معلوماتها التفصيلية
                    </p>
                  </motion.div>
                </div>
              )}
            </Card>
          </motion.div>
        </div>

        {/* Quick Links to Governorates */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 text-center">
            المحافظات اليمنية الـ 22
          </h3>
          <div className="flex flex-wrap justify-center gap-2">
            {governorates.map((gov) => (
              <motion.div
                key={gov.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Link
                  href={`/governorate/${gov.id}`}
                  className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-sm transition-all ${
                    selectedGovernorate?.id === gov.id
                      ? 'bg-red-600 text-white shadow-lg shadow-red-600/25'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:border-red-300 hover:text-red-600 dark:hover:border-red-700 dark:hover:text-red-400 shadow-sm'
                  }`}
                >
                  <span className="text-base">
                    {gov.region === 'north' ? '🏔️' : 
                     gov.region === 'west' ? '🌊' :
                     gov.region === 'east' ? '🏜️' :
                     gov.region === 'south' ? '🌴' :
                     gov.region === 'island' ? '🏝️' : '🏛️'}
                  </span>
                  {gov.name}
                </Link>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
