# STRICT_CONSTITUTION.md - The Supreme Law of Yemenpedia

> **THIS DOCUMENT IS THE SUPREME LAW. ALL CODE, CONFIGURATIONS, AND DECISIONS MUST COMPLY.**
> **LAST UPDATED: 2025-03-02 | VERSION: 1.1.0**
> **DAILY BOOTSTRAP PROTOCOL: Upon reading this file, the Agent MUST immediately reconfigure the environment using the credentials in Article VI.**

---

## ARTICLE I: TECHNICAL STACK GOVERNANCE

### Section 1.1: Database (POSTGRESQL ONLY)

| Rule | Requirement | Status |
|------|-------------|--------|
| **DB_PROVIDER** | PostgreSQL via Supabase (Frankfurt Region) | **MANDATORY** |
| **CONNECTION** | Pooler URL (`aws-1-eu-central-1.pooler.supabase.com:5432`) | **MANDATORY** |
| **POOL_MODE** | Session Mode | **MANDATORY** |
| **BAN_LIST** | SQLite, MySQL, MongoDB, Local DB Files | **STRICTLY BANNED** |

**Connection Format:**
```
postgresql://postgres.zvkswwhxgwnldapvcbuu:[PASSWORD]@aws-1-eu-central-1.pooler.supabase.com:5432/postgres
```

**Detection Protocol:**
```
IF DATABASE_URL contains "file:" OR "sqlite" → REJECT
IF db/custom.db exists → DELETE IMMEDIATELY
IF prisma/schema.prisma provider != "postgresql" → REJECT
```

### Section 1.2: Storage (CLOUD ONLY)

| Storage Type | Provider | Purpose |
|--------------|----------|---------|
| **Images** | Cloudflare R2 | Avatars, Article Images, Documents |
| **Videos** | Bunny Stream | Video Uploads, Streaming, Thumbnails |
| **Local Storage** | `/public/uploads/` | **STRICTLY BANNED** |

**R2 Configuration:**
```
R2_ACCOUNT_ID: db52bee9dafb8cae00b868b21b15adf9
R2_ACCESS_KEY_ID: 33912e32848ff9a9acd7fc2d84aa2a9d
R2_PUBLIC_URL: https://pub-fda2e1d132e7499993149b511aa93edc.r2.dev
R2_ENDPOINT: https://db52bee9dafb8cae00b868b21b15adf9.r2.cloudflarestorage.com
```

**Bunny Stream Configuration:**
```
BUNNY_API_KEY: 5da80b9a-3b12-4401-84b84d7d82b3-814e-41cc
BUNNY_LIBRARY_ID: 608086
BUNNY_CDN_HOSTNAME: vz-1eed252a-025.b-cdn.net
```

**Detection Protocol:**
```
IF any file written to /public/uploads/ → REJECT
IF fs.writeFile used for uploads → REJECT
IF image URL does not start with R2_PUBLIC_URL → REJECT
```

### Section 1.3: Image Processing Pipeline (SHARP)

**Every image MUST pass through this pipeline:**

| Step | Operation | Specification |
|------|-----------|---------------|
| 1 | **Format** | Convert to WebP |
| 2 | **Quality** | 80% (force) |
| 3 | **Metadata** | Strip ALL EXIF/GPS data |
| 4 | **Resize** | See table below |

**Resize Specifications:**

| Image Type | Dimensions | Aspect Ratio |
|------------|------------|--------------|
| Avatar | 400x400 px | 1:1 |
| Header/Cover | 1200x400 px | 3:1 |
| Article Featured | 1200x675 px | 16:9 |
| Article Content | 800x600 px | 4:3 |
| Thumbnail | 300x300 px | 1:1 |

---

## ARTICLE II: DESIGN & UI GOVERNANCE (THE "ARIAKIT" STANDARD)

### Section 2.1: The Minimalist Philosophy & Refactoring Rule

**DO NOT create duplicate or conflicting designs.** The design MUST mimic the absolute cleanliness of `ariakit.org` (Zero flag colors, zero clutter, extreme readability).

When working on UI:
1. **Find** the existing component.
2. **Refactor and Replace** its internal logic using `@ariakit/react` for flawless Accessibility (A11y).
3. **Strip away** old messy CSS and apply the Zinc style below.

### Section 2.2: Color System (Ultra-Neutral Zinc)

| Mode | Primary Background | Surfaces/Cards | Borders | Text | Accent/Focus |
|------|--------------------|----------------|---------|------|--------------|
| **Dark** | `zinc-950` (#09090b) | `zinc-900` | `zinc-800` | `zinc-50` | `blue-500` |
| **Light** | `zinc-50` (#fafafa) | `white` | `zinc-200` | `zinc-950` | `blue-600` |

### Section 2.3: Icon System & Focus States

| Rule | Requirement |
|------|-------------|
| **ALLOWED** | Lucide-React icons only |
| **BANNED** | Emojis, Unicode symbols, decorative hearts, stars |
| **FOCUS** | EVERY interactive element MUST have `focus-visible:ring-2 focus-visible:ring-blue-500` |

**Zero Emoji Policy:**
```
BANNED: ❤️, 🎉, ✨, 📚, 🗺️, 👥, 🏆, 💡, 📝, 🔍, 🌟
ALLOWED: <Heart />, <Sparkles />, <BookOpen />
```

### Section 2.4: Typography & RTL Mastery

| Language | Font | Configuration |
|----------|------|---------------|
| **Arabic (AR)** | IBM Plex Sans Arabic | `leading-loose`, `dir="rtl"` strict UI mirroring |
| **English (EN)** | Inter | `leading-relaxed` |

**Implementation:**
```tsx
import { IBM_Plex_Sans_Arabic, Inter } from 'next/font/google'
// Constrain articles for readability: className="max-w-prose"
```

---

## ARTICLE III: DATA INTEGRITY GOVERNANCE

### Section 3.1: Zero Placeholder Policy

| Rule | Requirement |
|------|-------------|
| **FAKE NUMBERS** | Strictly Banned (e.g., "1.2M users", "1250+ articles") |
| **LOREM IPSUM** | Strictly Banned |
| **DUMMY DATA** | Strictly Banned in production code |

**If Database is Empty:**
```
SHOW: Professional "No Content Yet" state
INCLUDE: CTA button (e.g., "Be the first to contribute")
NEVER: Show fake/inflated numbers
```

**Detection Protocol:**
```
IF hardcoded number > 0 in UI component → FETCH from DB or SHOW 0
IF "Lorem Ipsum" found → DELETE
IF placeholder image from unsplash/placeholder.com → REPLACE with real upload
```

---

## ARTICLE IV: OPERATIONAL GOVERNANCE

### Section 4.1: Daily Sandbox Recovery & Zero Hardcoding

Because the sandbox resets and forces SQLite via system env variables:

1. **REBUILD .env:** Always recreate `.env` using Article VI keys.
2. **ZERO HARDCODING:** NEVER hardcode the Supabase URL directly inside `src/lib/db.ts`.
3. **THE FIX:** Create a custom variable in `.env` (e.g., `SUPABASE_POOLER_URL`) and update `db.ts` to strictly use `process.env.SUPABASE_POOLER_URL` to bypass the sandbox conflict securely.

### Section 4.2: Audit-Before-Action Protocol

Before writing ANY code:
- Scan existing files for conflicts.
- Check `EXECUTION_LEDGER.json` for recent changes.
- Ensure you are REFACTORING old components, not creating duplicates.
- Confirm file path is correct.

### Section 4.3: Change Tracking

Every change MUST be logged in `EXECUTION_LEDGER.json`:
```json
{
  "step_id": "AUTO_INCREMENT",
  "timestamp": "ISO_TIMESTAMP",
  "task": "TASK_NAME",
  "files_modified": ["path/to/file"],
  "logic_applied": "SUMMARY",
  "reversion_plan": "UNDO_INSTRUCTIONS"
}
```

---

## ARTICLE V: ENFORCEMENT

### Violation Detection Checklist

- [ ] SQLite detected in `.env` or `prisma/schema.prisma`
- [ ] Files in `/public/uploads/`
- [ ] Emoji characters in UI components
- [ ] Hardcoded fake numbers
- [ ] Missing Sharp processing for images
- [ ] API keys hardcoded in `.ts/.tsx` files (Must be in `.env` only)
- [ ] Lorem Ipsum text
- [ ] Conflicting UI / Not using `@ariakit/react` for complex components

### Automatic Rejection Criteria

| Violation | Action |
|-----------|--------|
| SQLite usage | Block deployment |
| Local file uploads | Block deployment |
| Emoji in production | Block deployment |
| Fake statistics | Block deployment |
| Hardcoded secrets in code | Block deployment |
| Flashy colors / Non-Zinc palette | Block deployment |

---

## ARTICLE VI: VERIFIED CREDENTIALS

### Database (PostgreSQL - Supabase Frankfurt)

```
Project: yemenpedia-Data
Pooler Host: aws-1-eu-central-1.pooler.supabase.com
Port: 5432
Database: postgres
User: postgres.zvkswwhxgwnldapvcbuu
Password: L42GiU5eRE/YSQy (URL encoded: L42GiU5eRE%2FYSQy)
Pool Mode: Session
```

### Storage (Cloudflare R2)

```
Account ID: db52bee9dafb8cae00b868b21b15adf9
Access Key ID: 33912e32848ff9a9acd7fc2d84aa2a9d
Secret Access Key: 30b5a4dc8372b1c13b3a1876c5df654091b2bcb74235599fc50fe891d0445706
Bucket Name: yemenpedia-media
Public URL: https://pub-fda2e1d132e7499993149b511aa93edc.r2.dev
Endpoint: https://db52bee9dafb8cae00b868b21b15adf9.r2.cloudflarestorage.com
```

### Video (Bunny Stream)

```
API Key: 5da80b9a-3b12-4401-84b84d7d82b3-814e-41cc
Library ID: 608086
CDN Hostname: vz-1eed252a-025.b-cdn.net
```

### Email (Resend)

```
API Key: re_UMqAEhxv_FEZFRrPrb8ctntiPKxFiHmY9
```

### OAuth (Google)

```
Client ID: 44781426926-u6381r5hdm7mr9em1bojh0h9t944aq1r.apps.googleusercontent.com
Client Secret: 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
```

### Authentication

```
NEXTAUTH_SECRET: yemenpedia-super-secret-key-2025
NEXTAUTH_URL: http://localhost:3000
```

---

**THIS CONSTITUTION IS FINAL AND NON-NEGOTIABLE.**

*Signed: Yemenpedia Governance System*
*Effective: Immediately upon creation*
